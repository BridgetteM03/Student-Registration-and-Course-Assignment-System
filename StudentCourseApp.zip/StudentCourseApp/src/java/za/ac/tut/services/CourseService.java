/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.services;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import za.ac.tut.entities.Course;
import za.ac.tut.entities.Enrollment;
import za.ac.tut.entities.Student;

/**
 *
 * @author Bridgette Mokone
 */
@Stateless
public class CourseService {
    @PersistenceContext(unitName = "StudentCoursePU")
    private EntityManager em;

    public void addCourse(String title) {
        Course c = new Course();
        c.setTitle(title);
        em.persist(c);
    }

    public void enrollStudent(int studentId, int courseId) {
        Student student = em.find(Student.class, studentId);
        Course course = em.find(Course.class, courseId);

        Enrollment e = new Enrollment();
        e.setStudent(student);
        e.setCourse(course);
        em.persist(e);
    }

    public List<Course> getAllCourses() {
        return em.createQuery("SELECT c FROM Course c", Course.class).getResultList();
    }
}
