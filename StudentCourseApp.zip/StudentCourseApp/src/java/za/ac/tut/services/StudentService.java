/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.services;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import za.ac.tut.entities.Student;

/**
 *
 * @author Bridgette Mokone
 */
@Stateless
public class StudentService {
    @PersistenceContext(unitName = "StudentCoursePU")
    private EntityManager em;
    
    
    public void addStudent(String name) {
        Student s = new Student();
        s.setName(name);
        em.persist(s);
    }

    public List<Student> getAllStudents() {
        return em.createQuery("SELECT s FROM Student s", Student.class).getResultList();
    }
}
